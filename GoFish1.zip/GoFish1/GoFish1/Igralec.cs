﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoFish1
{
    internal class Igralec //človek ali računalnik
    {
        public string Ime;
        public Kup roka; //karte, ki jih ima igralec v roki
        Random r=new Random();
        TextBox textNaFormi;
        public Igralec(string i, Random r, TextBox t)
        {
            //Konstruktor inicializira atribute Igralca
            //v vnosno polje doda tekst "Joe se je pridružil igri"
            ////in prehod 
            //v novo vrstico
            Ime = i;
            this.r = r;
            textNaFormi = t;
            roka = new Kup(new Karta[] { });
            textNaFormi.Text += Ime + " se je pridružil igri\n";
        }

    }
}
